/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Piky
 */
public class Materia {
    
    public String nombre;
    public int creditos;
    public int clave;
    public int semestre;

    public Materia(String nombre) {
        this.nombre = nombre;
    }
    
    
}
