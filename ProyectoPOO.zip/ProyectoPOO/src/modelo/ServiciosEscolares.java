/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;

/**
 *
 * @author Piky
 */
public class ServiciosEscolares {
    public ArrayList<Alumno> Lista = new ArrayList<>();
    public ArrayList<Materia> ListaMaterias = new ArrayList<>();
    
    public void ModGenNumInsc(){
    }
    public void AsigNumInsc(){
        
        
    }
    public void ModGenNombre(){
        //Se egenran los nombres de los alumnos de manera aleatoria
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        ArrayList<String> ListaNombres = new ArrayList<>();
        ArrayList<Integer> ListaRepetidos = new ArrayList<>();
        
        try{
            FileReader fr = new FileReader("Nombres.csv");
            br = new BufferedReader(fr);
            System.out.println("El texto del archivo es: ");
            String linea = br.readLine();
            
            while(linea != null){
                ListaNombres.add(linea);
                linea = br.readLine();
            }
            br.close();
        } catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        int tamaño = ListaNombres.size();
        Random random = new Random();
        while (ListaRepetidos.size() < 50){
            
            int posicion = random.nextInt(tamaño);
            
            if(!ListaRepetidos.contains(posicion)){             
                Alumno alumno = new Alumno();
                alumno.nombre = ListaNombres.get(posicion);
                Lista.add(alumno);
                ListaRepetidos.add(posicion);
            }
        }
        
    }
    public void ModGenDatosP(){
        //Aqui se generan los semestre basandonos en la edad del alumno
        for (int i = 0; i < Lista.size(); i++) {
            Random random = new Random();
            int edad = random.nextInt(9)+18;
            Lista.get(i).edad = edad;
            if(Lista.get(i).edad >= 18 && Lista.get(i).edad <= 20 ){               
                int semestre = random.nextInt(3)+1;
                Lista.get(i).semestre = semestre;
            }
            if(Lista.get(i).edad > 20 && Lista.get(i).edad <= 22 ){               
                int semestre = random.nextInt(5)+3;
                Lista.get(i).semestre = semestre;
            }
            if(Lista.get(i).edad > 22 && Lista.get(i).edad <= 24 ){               
                int semestre = random.nextInt(3)+7;
                Lista.get(i).semestre = semestre;
            }
            if(Lista.get(i).edad > 24 && Lista.get(i).edad <= 27 ){               
                int semestre = random.nextInt(1)+9;
                Lista.get(i).semestre = semestre;
            }  
        }
        
        //Se generan las direcciones aleatoriamente
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        ArrayList<String> ListaDirecciones = new ArrayList<>();
        ArrayList<Integer> ListaRepetidos = new ArrayList<>();
        
        try{
            FileReader fr = new FileReader("Direcciones.csv");
            br = new BufferedReader(fr);          
            String linea = br.readLine();
            
            while(linea != null){
                ListaDirecciones.add(linea);
                linea = br.readLine();
            }
            br.close();
        } catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        int tamaño = ListaDirecciones.size();
        int lugar = 0;
        Random random = new Random();
        
        while (ListaRepetidos.size() < 50){
            
            int posicion = random.nextInt(tamaño);
            
            if(!ListaRepetidos.contains(posicion)){             
                Lista.get(lugar).direccion = ListaDirecciones.get(posicion);
                lugar ++;
                ListaRepetidos.add(posicion);
            }
        }
        
    }
        
    public void ModGenRAcademico(){
        
        //Recupera los datos de las materias y los guarda en un arreglo
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        ArrayList<Integer> ListaRepetidos = new ArrayList<>();
        
        System.out.println(ListaMaterias.size());
        try{
            FileReader fr = new FileReader("Materias.csv");
            br = new BufferedReader(fr);;
            String linea = br.readLine();
            int control = 0;
            int posicion=0;
            while(linea != null){               
                StringTokenizer tokenizador = new StringTokenizer(linea,",");
                while(tokenizador.hasMoreTokens()){
                    if(control == 0){
                        String token = tokenizador.nextToken();
                        ListaMaterias.add(new Materia(token));
                        ListaMaterias.get(posicion).nombre = token;
                    }
                    if(control == 1){
                        String token = tokenizador.nextToken();                       
                        ListaMaterias.get(posicion).creditos = Integer.parseInt(token);    
                    }
                    if(control == 2){
                        String token = tokenizador.nextToken();
                        ListaMaterias.get(posicion).clave = Integer.parseInt(token);
                    }
                    if(control == 3){
                        String token = tokenizador.nextToken();
                        ListaMaterias.get(posicion).semestre = Integer.parseInt(token);
                    }
                                      
                    control++;
                }
                control = 0;
                posicion++;
                linea = br.readLine();
            }
            br.close();
        } catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
        System.out.println(ListaMaterias.size());
        for (int i = 0; i < ListaMaterias.size(); i++) {
            System.out.println("Materia: "+ListaMaterias.get(i).nombre);
            System.out.println("creditos: "+ListaMaterias.get(i).creditos);
            System.out.println("clave: "+ListaMaterias.get(i).clave);
            System.out.println("semestre: "+ListaMaterias.get(i).semestre);
        }
        
        
        for (int i = 0; i < Lista.size(); i++) {
            System.out.println("nombre: "+Lista.get(i).nombre);           
            System.out.println("edad: "+Lista.get(i).edad);
            System.out.println("semestre: "+Lista.get(i).semestre);
            System.out.println("direccion: "+Lista.get(i).direccion);
        }
        
        //Asignar asignaturas a alumnos
        
        for (int i = 0; i < Lista.size(); i++) {
            Random random = new Random();
            if(Lista.get(i).semestre == 1){               
                for (int j = 0; j < 5; j++) {
                    int x = random.nextInt(4)+6;
                    Lista.get(i).materias.add(new Calificacion(ListaMaterias.get(j).nombre,x));
                    System.out.println("Materias: "+Lista.get(i).materias.get(j).materia+" Calif: "+Lista.get(i).materias.get(j).calif);
                }
                
            }
        }
        
    }
    
    
}
