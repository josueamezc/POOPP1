/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Piky
 */
public class Calificacion {
    
    public String materia;
    public int calif;

    public Calificacion(String materia, int calif) {
        this.materia = materia;
        this.calif = calif;
    }
    
    
}
