/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author Piky
 */
public class Alumno {
    public String nombre;
    public int edad;
    public int semestre;
    public String direccion;
    public ArrayList<Calificacion> materias = new ArrayList<>(); 
    public double promedio;
    public int numCreditos;
    private int NumCuenta;
    // lista ligada asignaturas //

    public Alumno(String nombre) {
        this.nombre = nombre;
    }

    public Alumno() {
    }
       
    
}
